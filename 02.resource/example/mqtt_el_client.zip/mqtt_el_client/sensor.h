#ifndef SENSOR_MODULE_H //ifndef => if not define
#define SENSOR_MODULE_H

// Khai bao nguyen ham
void sensor_setup();
float sensor_process();

#endif/* SENSENSOR_MODULE_H */
